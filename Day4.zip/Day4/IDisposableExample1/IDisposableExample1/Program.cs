﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IDisposableExample
{
    internal class Program
    {

        // after using "using block " direct implementing 
        // dispose method  
        // when only possible when you write line 24 see 
        static void Main1(string[] args)
        {
            class1 o = new class1();
                o.Display();
            o.Dispose();
           
            o.Display();
            Console.ReadLine();
        }
        static void Main(string[] args)
        {
            class2 o = new class2();
            o.Display();
            o.Dispose();
            //without using "using block" stop exeuting after 
            // excuting the dispose method call. 
            // to malke this we make a new    scenario 
            o.Display();
            Console.ReadLine();
        }
    }
    // this IDisposable interface ypu can write directly  
    public class class1 : IDisposable
    {
        public class1()
        {
            Console.WriteLine("constructor");
        }

        public void Display()
        {
            Console.WriteLine("display");
        }


        // below method is present with IDispoasable interface 
        // without Dispose method get error 
        public void Dispose()
        {
            // you can  used dispose method instead of destructor
            Console.WriteLine("displose class1");
        }
    }
    public class class2 : IDisposable
    {
        private bool isDispose;

        public class2()
        {
            Console.WriteLine("2nd const.");

        }
        public void Display()
        {
            Console.WriteLine();
            checkedforDispose();
        }

        public void Dispose()
        {
            checkedforDispose();

            Console.WriteLine("dispose called ");
            isDispose = true;
        }

        private void checkedforDispose()
        {
            if(isDispose)
            throw new ObjectDisposedException("class1");
        }
    }

}
