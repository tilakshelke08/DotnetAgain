﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ENUM
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Display(0);
            Display(10);
            Console.WriteLine();
            Console.ReadLine();
        }
        static void Display(int n)
        {
            if (n == 0)
            {
                Console.WriteLine("good morining ");
            }
            if (n == 1)
            {
                Console.WriteLine("good afternoon ");
            }
            if (n == 2)
            {
                Console.WriteLine("good evening ");
            }
            if (n == 3)
            {
                Console.WriteLine("good night  ");
            }
        }
    }
    public enum TimeOfDay
    {
       Morning ,
       Afternoon,
       Evening,
       Night
    }
    
}
 