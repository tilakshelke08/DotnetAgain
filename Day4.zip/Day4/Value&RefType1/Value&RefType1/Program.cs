﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Value_ReferenceType
{
    internal class Program
    {
        static void Main1(string[] args)
        {
            // value type 
            //stack stored

            // struct and enum
            int o1;
            int o2;

            o1 = 100;
            o2 = 200;
            o1 = o2;   
            o2 = 300;


            Console.WriteLine(o1); //200
            Console.WriteLine(o2); //300
            Console.ReadLine();
        }
        static void Main(string[] args)
        {
            // string is ref type 
            // string is implement diff from ref type.

            //but they work as int/value  type 

           
            string o1;
            string o2;

            o1 = "100";
            o2 = "200";
            o1 = o2;
            o2 = "300";

            Console.WriteLine("----");
            Console.WriteLine(o1); //200
            Console.WriteLine(o2); //300
            Console.ReadLine();
        }
    }
   

}
