﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IDisposableExample
{
    internal class Program
    {

        // after using "using block " direct implementing 
        // dispose method  
        // when only possible when you write line 24 see 
        static void Main(string[] args)
        {
            using (class1 o = new class1()) 
              o.Display();
            Console.ReadLine();
        }
        
    }
    // this IDisposable interface ypu can write directly  
    public class class1 : IDisposable
    {
        public class1(){
            Console.WriteLine("constructor");
        }
            
        public void Display() {
            Console.WriteLine("display");
                }


        // below method is present with IDispoasable interface 
        // without Dispose method get error 
        public void Dispose()
        {
            // you can  used dispose method instead of destructor
            Console.WriteLine("displose class1");
        }
    }

}
