﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Val_RefType4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            class1 o = new class1();
            o.i = 100;
            DoSomething(o);
            DoSomething1(o);
            DoSomething2(ref o);
            Console.WriteLine(o.i); 
            Console.ReadLine();
        }

        static void DoSomething2( ref class1 o)
        { // if used "ref" keyword  and if you 
            // instantiated a new class with o 
            //then you can recive only those value 
            // which you are mentioned in method eg. 500
            o = new class1();
            o.i = 500;
        }

        static void DoSomething(class1 o)
        {    // obj =o;
            o.i = 200;  //it give me rigth value 200
        }
        static void DoSomething1(class1 o)
        {
           // before below this  //obj =o;
            o= new class1(); 
            o.i = 3000; //why --it give 100 

            // look line 38
            // we intiallised new cass that is diff from
            // line no  13.thats whythey give me 100 
        }
    }
    public class class1
    {
        public int i;

    }
}
