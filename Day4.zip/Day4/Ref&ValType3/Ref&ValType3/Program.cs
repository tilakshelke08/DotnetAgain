﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ref_ValType3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // if u could not
            // write  ref then the ans is already  write in comment
            int a = 123;
            int b = 456;

            swap(ref a, ref b);

            Console.WriteLine(a); //123
            Console.WriteLine(b); //456
            Console.WriteLine("--------");
            Console.ReadLine();
        }

         static void swap(ref int i,ref int j)
        {
            int temp = i;
            i = j;
            j = temp;

            /* Console.WriteLine(i); //456
             Console.WriteLine(j); //123
             Console.WriteLine("--------");*/
        }
    }
}
