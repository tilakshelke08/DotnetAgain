﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Val_RefType5
{
    internal class Program
    {
        static void Main(string[] args)
        {
        }
    }
    public struct Mypoint
    {
        public int A
        {
            get; set;
        }
        public int X, Y;
        public void Mypoint(int X = 0, int Y = 0, int A = 0)
        {
            Console.WriteLine("cons callled ");

            this.X = X;
            this.Y = Y;
            this.A = A;
        }
    }
}
