﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TypeCasting
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int? i;
            // ? makes the above code nullable 
            i = 10;

            /* int m;
              m = ? null;*/
            // if you write ? mark
            // then they cant give you error 


            // short ? sh;
            //double ? d;

            int j;
            j = (int)i; //type casting 
            Console.WriteLine(j);
            Console.ReadLine();


            j = i ?? 10; // null coalescing operator
        }
    }
}
