﻿using System;
namespace InterfaceInCore
{
    internal class Program
    {
        static void Main(string[] args)
        {
            class1 o = new class1(); 
           

            // the deafult method you can acces by interface  implementation    
            IDBFunction IDB;
            IDB = o;
            IDB.DefaultMethod();

            // In .Net core don't need to write Readline statment 
        }
    }
    public interface IDBFunction
    {
        void insert();
        void update();
        void delete();

        // this is default implementaion of interfacee method 
        /*if u give semicolon like above method they show error. 
        they must not be need semicolon*/
        /*
         why u wrute this method:- if the class doesnt implement 
         the code then used such type of default method to write the code */
        void DefaultMethod()
        {
            Console.WriteLine("default method implemented by interface ");
        }
}
    public class class1 : IDBFunction
    {
        public void Display()
        {
            Console.WriteLine("class1 : display");
        }
        public void delete()
        {
            Console.WriteLine("class1 : delete");
        }

        public void insert()
        {
            Console.WriteLine("class1 : insert");
        }

        public void update()
        {
            Console.WriteLine("class1 : update");
        }

        
        // if ambiquity found i.e multiple method by same name then used method explicit implimentaion 
       // some confusing this method 
        void IDBFunction.DefaultMethod()
        {
            Console.WriteLine("class1 default method");
        }
    }
}