﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
namespace Collections
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /* when you talikung about collections always remeember 
             1.Add  
              2.Remove
               3.Count 
            */

            // arraytlist  passed by any obj like 
            // string ,integer,float etc.

            // creation of obj 
            ArrayList o= new ArrayList();

            // Add method 
            o.Add(10);
            o.Add(1.20);
            o.Add("Tilak");Console.WriteLine(o.Count);

            // Remove method 
            o.Remove(10);
            //removeAt(1)    i.e remove the element at the  "1" index 
            // don't confused in..
            // remove & removeAt

            /*  by the used of this i can add any collections
              obj .*/
            //  o.AddRange(o2);
            /* suppose  "o2" is the another arraylist 
               so from the above line you can transfer the
              "o2" arraylist obj  to the "o" arraylist obj
            */

            o.Insert(0, "string");
            // you can used "insert" instead of 'Add'
            // 1.first is index
            // 2. any collectoon obj .

            // o.InsertRange(0, o2);

            // o.RemoveRange(0, o2);
            // remove multiple item one time 
            //1.start the item 
            //2. no. of items remove 

            // o.Clear();    // in collection ..remove all
            
        // o.clear();  // in array... it assign the default values

            //o. clone(); ....created shallow copy

            //o. contain();
            //return boolean value 
            // if value present in collection 
            // thhen return  "True"
            //iif not return "False";
            // below "o" is an collections

            //o.indexOf();
            //o.LastindexOf();
            //o.BinarySearch();

            // o.copyTo();
            // copy from arraylist to array 

            o.GetRange(0,10);
            // 1.start with 0
            //2.end with 10

          //  o.SetRange(0, o2);
          // it used for overwritten the 
          // "o2" value put in "o" and overwrite
            foreach (var item in o)
            {
                Console.WriteLine(item);
            }
           
            Console.ReadLine();
        }
    }
}
