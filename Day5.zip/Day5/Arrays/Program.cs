﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Arrays
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // initializaitions 
            int[] arr = new int[5];
            for (int i = 0; i < arr.Length; i++)
            {
                Console.WriteLine(i);

                // take input frrom user
                // console .readline always return in string ;

                /* int.parse spacially for 
                 string to int */
                arr[i] = int.Parse(Console.ReadLine());

                // another way 

                // this metod  you can convert into 
                // any data type 
                //  arr[i] = Convert.ToInt32(Console.ReadLine());
            }
            for (int i = 0; i < arr.Length; i++)
            {
                Console.WriteLine("the number: ", i, arr[i]);
                Console.WriteLine($"the number {i}is {arr[i]}");
                Console.ReadLine();

            }
        }
    }
}
