﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Jagged
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //jagged array
            // how many you want array to write in 3rd box i.e 4 row 
            int[][] arr = new int[4][];

            // In 0 row how many numbers you want 
            arr[0] = new int[3]; // arr[0][0] arr[0][1] arr[0][2]
            arr[1] = new int[4]; // arr[1][0] arr[1][1] arr[1][2] arr[1][3]
            arr[2] = new int[2]; // arr[2][0] arr[2][1]
            arr[3] = new int[3]; // arr[3][0] arr[3][1] arr[3][2]

            // this for loop to just taking the input from users 
            for (int i = 0; i < arr.Length; i++)
            {
                for (int j = 0; j < arr[i].Length; j++)
                {
                    // print the line before taking the value from users
                    Console.Write("the value  of i & j :", i, j);
                    //below line wass write due to taking thee input from users  and input is stored in "arr[i][j]"
                    /*arr[i][j] = int.Parse(Console.ReadLine());*/
                    arr[i][j] = Convert.ToInt32(Console.ReadLine());
                    // "console.readline()" return the string data  that data convert into Integer
                }
                Console.WriteLine();
                Console.WriteLine();

            }
            Console.WriteLine();
            Console.WriteLine();
            // this for loop to print the value from the users 
            for (int i = 0; i < arr.Length; i++)
            {
                for (int j = 0; j < arr[i].Length; j++)
                {
                    // In the above for loop "arr[i][j] getting the user data .
                    Console.WriteLine("the value of i & j  & arr[i][j] :"+ arr[i][j]);
                }
                
            }
            Console.ReadLine();
        }   
        
    }
}
