﻿namespace JaggedEmployee
{
    internal class Employee
    {
    }
}