﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JaggedEmployee
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Employee [][] EmpArr = new Employee[4][];
            {
                for (int i=0;i<EmpArr.Length;i++)
                {
                    EmpArr[i]= new Employee[i];
                }

            }
            Console.WriteLine();

            for(int i=0;i<EmpArr.Length;i++)
            {
                for(int j = 0; j < EmpArr[i].Length; j++)
                {
                    Console.WriteLine("the emp numer:" + i, j);
                    EmpArr[i][j] = Convert.ToInt32(Console.ReadLine());
                }
            }
            Console.WriteLine();
            Console.WriteLine();

            Console.WriteLine();
            Console.WriteLine();

            for (int i = 0; i < EmpArr.Length; i++)
            {
                for (int j = 0; j < EmpArr[i].Length; j++)
                {
                    Console.WriteLine("the emp numer:" + EmpArr[i][j]);
                    
                }
            }
            Console.ReadLine();
        }
    }
}
